function TaperedGR_Confidence_Region_Estimation( Data , MagnitudeColumn , MagnMinVector , BetaVector , CornerMagnitudeVector )

% This function computes and plots the 95% confidence interval of the parameters
% of tapered Gutenberg-Richter distribution using the "profile likeilhood method"

% INPUT
%
% Data : seismic catalog
%
% MagnitudeColumn : the magnitude column of the catalog
%
% MagnMinVector : vecotor of the magnitudes of completeness for the catalog
%
% BetaVector : vector of  the parameter of the Tapered GR distribution
%
% CornerMagnitudeVector : vector of the parameter of the Tapered GR distribution


% compute the length of the vectors of parameters
n1 = length( BetaVector ) ;
n2 = length( CornerMagnitudeVector ) ;

% number of events in the catalog
N = size( Data , 1 ) ;  

% convert magnitudes to moments (the specific law used in this conversion
% do not affect the final computation)
Moments = 10.^(3/2*( Data( : , MagnitudeColumn ) + 10.733 ) ) ; % convert magnitudes to seismic moment
Mt = 10.^(3/2*( MagnMinVector + 10.733 ) ) ;                    % convert MagnMinVector to seismic moment
Mc = 10.^(3/2*( CornerMagnitudeVector + 10.733 ) ) ;            % convert CornerMagnitudeVector to seismic moment

% preallocation of the log-likelihood matrix
LL = zeros( n1 , n2 ) ;  

for i = 1 : n1
    for j = 1 : n2
        
        % compute the log-likelihood for the Tapered Gutenberg-Richter distribution
        % for catalogs with variable magnitude of completeness
        LL( i , j ) = TaperedGR_LogLikelihood( Moments , Mt , BetaVector(i) , Mc(j) ) ;
        
    end
end


% maximum log-likelihood
LLmax = max( max( LL ) ) ;  

% 95% confidence interval with the "profile likeilhood method", is it
% possible to change this value to obtain different confidence intervals
LL95 = LLmax - 2.995 ; 

% contour plot of the log-likelihood and 95% confidence interval
[ C , h ] = contour( BetaVector , CornerMagnitudeVector , LL' , [LL95 LL95] ) ; 

hold on ; box on

% find the MLE values for the parameters
[ BetaIndex , McIndex ] = find( LL == LLmax ) ;

% plot the MLE point estimation
plot( BetaVector( BetaIndex ) , CornerMagnitudeVector( McIndex ) , '.' )

% labels for X and Y axis
xlabel( 'Beta' )
ylabel( 'Corner Magnitude' )

hold off

