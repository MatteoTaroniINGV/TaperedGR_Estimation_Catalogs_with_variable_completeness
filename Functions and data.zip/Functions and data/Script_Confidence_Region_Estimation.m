% Script to computes the parameters of the tapered Gutenberg-Richter law 
% and their 95% confidence interval (Beta and corner magnitude) 
% No Poisson assumption needed for this computation.

% load the seismic catalog
% the catalog in this case in ZMAP format, plus Strike, Dip and Rake for
% the first and second nodal plane of the CMT catalog, plus the magnitude
% of completeness (17-th column).
Catalog = load( 'Cat_Izu_Mariana_Complete_55_50.txt' ) ;

% the magnitude column of the catalog (in the ZMAP format is the 6-th
% column)
MagnitudeColumn = 6 ;

% vector of the magnitudes of completeness of the catalog (in our format 
% this information is stored in the 17-th column of the catalog)
MagnMinVector = Catalog( : , 17 ) ;

% magnitude binning
Bin = 0 ;

% possible values of the parameters for the confidence interval estimation
% (we used a brute-force approach)
BetaVector            = 0.3 : 0.01 : 1.0 ;
CornerMagnitudeVector = 5.6 : 0.01 : 8.0 ;

% plot the 95% confidence interval of the parameters of Tapered 
% Gutenberg-Richter law using the "profile likeilhood method"
TaperedGR_Confidence_Region_Estimation( Catalog , MagnitudeColumn , ...
                     MagnMinVector , BetaVector , CornerMagnitudeVector ) ;