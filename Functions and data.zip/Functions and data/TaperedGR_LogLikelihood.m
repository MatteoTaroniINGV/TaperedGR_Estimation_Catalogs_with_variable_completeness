function CumLL = TaperedGR_LogLikelihood( Moments , MomC , Beta , CMom ) 

% INPUT
%
% Moments : vector with the seismic moments of the catalog
%
% MomC : vector with the seismic moments of completeness of the catalog
%        (must have the same length of 'Moments')
%
% Beta : slope of the tapered Gutenberg-Richter distribution
% CMom : corner moment of the tapered Gutenberg-Richter distribution 

% OUTPUT
%
% CumLL : cumulative log-likelihood


% preallocation of the log-likelihood vector
LL = zeros( 1 , length( Moments ) ) ;

% loop 'for' to compute the log-likelihood for each seismic moment
% and the corresponding seismic moment of completeness
for i = 1 : length( Moments )

    % log-likelihood computation
    LL( i ) = log( Beta/Moments(i) + 1/CMom ) + Beta*log( MomC(i)/Moments(i) ) ...
              + ( (MomC(i) - Moments(i) )/CMom ) ;

end

% compute the cumulative log-likelihood
CumLL = sum( LL ) ;